# Python serverless TO DO

A Python aws lambda serverless api to manage tasks.
A simple TODO CRUD example to practice.

### Use Case Rules

- [x] Create Tasks
- [x] Get all Tasks
- [x] Get a specific Task by id
- [x] Complete a specific Task by id
- [x] Update a specific Task by id
- [x] Delete a specific Task by id

### Next Steps

- [x] Implement Custom Exceptions
- [ ] Create Localstack container
- [ ] Deploy a lambda function
