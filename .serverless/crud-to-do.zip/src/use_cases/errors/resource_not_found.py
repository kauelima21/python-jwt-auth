class ResourceNotFoundError(Exception):
  pass
